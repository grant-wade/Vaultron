Vaultron (Cross Platform Password Manger)
(Colton King, Grant Wade, Robby Boney, Rob Wooner)

Requirements:
    - Node.js
        - https://nodejs.org/en/
        - Version 7.9.0 --> Current will work

How to Run:
    Once node.js is install on your computer
    and you are able to use npm in the terminal
    move to the source directory and run the following
        npm install
    That will install all of the packages required
    in packages.json and they will be the versions
    required in package-lock.json.
   
    Then to run Vaultron run the following:
        npm start
    That will launch the start script setup
    in the package.json file. If there are
    any problems running Vaultron email
    grant.wade@wsu.edu

